<?php

namespace TypechoPlugin\LENS;

use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Text;
use Typecho\Widget\Helper\Form\Element\Radio;
use Utils\Helper;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * 相册 - LENS
 *
 * @package LENS
 * @author Lin./https://linyu.live
 * @version 1.1.0
 */
class Plugin implements PluginInterface
{
    /**
     * 激活插件方法
     */
    public static function activate()
    {
        // 路由为 /lens
        Helper::addRoute('lens', '/lens', 'LENS_Action', 'render');
        
        return _t('相册插件已激活，访问 你的域名/lens 查看相册');
    }

    /**
     * 禁用插件方法
     */
    public static function deactivate()
    {
        Helper::removeRoute('lens');
        
        return _t('相册插件已禁用');
    }

    /**
     * 获取插件配置面板
     */
    public static function config(Form $form)
    {
        // 相册标题（顶栏 + 首图大标题）
        $title = new Text('title', null, '我的相册', _t('相册标题'), _t('显示在顶栏和首图左下角的大标题'));
        $form->addInput($title);
        
        // 相册副标题（首图英文小字）
        $description = new Text('description', null, 'Scenery along the way', _t('相册副标题'), _t('显示在首图左下角的小字/英文'));
        $form->addInput($description);
        
        // 默认分类ID
        $category = new Text('category', null, '2', _t('默认分类ID'), _t('默认提取哪个分类下的文章图片（可在页面URL参数覆盖，如 ?category=3）'));
        $form->addInput($category->addRule('isInteger', _t('必须是数字')));
        
        // 头部背景图URL - 改为相机图片
        // 提示：请将相机图片上传到插件目录 usr/plugins/LENS/img/ 下，或填写图床链接
        $defaultBg = '/usr/plugins/LENS/img/photo.webp'; // 默认使用本地相机图
        
        $headerBg = new Text('headerBg', null, $defaultBg, _t('首图背景'), _t('请将相机图片上传到 usr/plugins/LENS/img/ 文件夹并命名为 camera-bg.jpg，或填写完整URL如 https://你的图床.com/photo.webp'));
        $form->addInput($headerBg);
        
        // 网格布局列数
        $gridColumns = new Radio('gridColumns', 
            ['3' => _t('三列网格（小图，密集瀑布流）'), '2' => _t('双列网格（大图，带日期卡片）')], 
            '3', 
            _t('网格布局')
        );
        $form->addInput($gridColumns);
    }

    /**
     * 个人用户的配置面板
     */
    public static function personalConfig(Form $form)
    {
    }
}

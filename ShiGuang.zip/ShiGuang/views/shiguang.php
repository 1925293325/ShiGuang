<?php
/**
 * /shiguang 路由专用视图
 */

use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$opts = Options::alloc()->plugin('ShiGuang');
$gridColumns = intval($opts->gridColumns) ?: 3;

$allArticles = [];
try {
    if (class_exists('TypechoPlugin\ShiGuang\Plugin')) {
        $allArticles = \TypechoPlugin\ShiGuang\Plugin::getAlbumData();
    }
} catch (\Throwable $e) { $allArticles = []; }

$pluginUrl = Options::alloc()->pluginUrl . '/ShiGuang';
$albumTitle = $opts->title ?? '我的相册';
$albumDesc = $opts->description ?? '';
$headerBg = !empty($opts->headerBg)
    ? (strpos($opts->headerBg, 'http') === 0 ? $opts->headerBg : $pluginUrl . '/' . ltrim($opts->headerBg, '/'))
    : '';
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?= htmlspecialchars($albumTitle) ?></title>
    <link rel="stylesheet" href="<?= $pluginUrl ?>/views/shiguang.css">
    <style>
        .sg-hero {
            position: relative;
            height: 28vh;
            min-height: 160px;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            padding: 0 16px 20px;
            background: linear-gradient(to bottom, rgba(0,0,0,0) 0%, rgba(0,0,0,0.55) 100%), url('<?= htmlspecialchars($headerBg) ?>') center/cover no-repeat;
            color: #fff;
        }
        .sg-hero h1 { font-size: 1.6rem; font-weight: 700; margin: 0 0 6px; letter-spacing: 1px; }
        .sg-hero p { font-size: 0.8rem; opacity: 0.75; margin: 0; }
        @media (min-width: 768px) {
            .sg-hero { height: 24vh; min-height: 200px; padding: 0 24px 28px; }
            .sg-hero h1 { font-size: 2rem; }
            .sg-hero p { font-size: 0.9rem; }
        }
    </style>
</head>
<body>

<!-- 手机端顶栏 -->
<div class="sg-mobile-header">
    <a href="javascript:history.back()" class="sg-back">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
    </a>
    <h1><?= htmlspecialchars($albumTitle) ?></h1>
    <span style="width:24px;"></span>
</div>

<div class="sg-hero">
    <h1><?= htmlspecialchars($albumTitle) ?></h1>
    <p><?= htmlspecialchars($albumDesc) ?></p>
</div>

<div class="sg-page">
    <div class="sg-wrap">
        <main>
<?php if (empty($allArticles)): ?>
            <div class="sg-empty">
                <div class="icon">📷</div>
                <div class="txt">暂无图片</div>
            </div>
<?php else: ?>

<?php if ($gridColumns == 2): ?>
<div class="sg-waterfall" id="sgWaterfall">
<?php $articleIndex = 0; foreach ($allArticles as $article):
    $isSingle = $article['count'] <= 1;
    $firstImg = $article['images'][0];
    $delay = min($articleIndex * 0.08, 0.8);
?>
  <div class="sg-wf-item sg-reveal"
       data-index="<?= $articleIndex ?>"
       data-cid="<?= $article['cid'] ?>"
       style="animation-delay: <?= $delay ?>s">
    <div class="sg-wf-visual">
      <img src="<?= htmlspecialchars($firstImg['thumb']) ?>"
           alt="<?= htmlspecialchars($article['title']) ?>"
           loading="lazy">
      <?php if (!$isSingle): ?>
      <div class="sg-wf-count"><?= $article['count'] ?></div>
      <?php endif; ?>
    </div>
    <div class="sg-wf-body">
      <div class="sg-wf-title"><?= htmlspecialchars($article['title']) ?></div>
      <div class="sg-wf-date"><?= htmlspecialchars($article['date']) ?></div>
    </div>
  </div>
<?php $articleIndex++; endforeach; ?>
</div>

<?php else: ?>
<?php
$flatImages = [];
foreach ($allArticles as $article) {
    foreach ($article['images'] as $img) {
        $flatImages[] = [
            'url'       => $img['url'],
            'thumb'     => $img['thumb'],
            'title'     => $article['title'],
            'permalink' => $article['permalink']
        ];
    }
}
?>
<div class="sg-3col" id="sg3col">
<?php $globalIndex = 0; foreach ($flatImages as $img): ?>
  <div class="sg-photo sg-reveal"
       data-index="<?= $globalIndex ?>"
       data-url="<?= htmlspecialchars($img['url']) ?>"
       data-title="<?= htmlspecialchars($img['title']) ?>"
       data-thumb="<?= htmlspecialchars($img['thumb']) ?>"
       data-permalink="<?= htmlspecialchars($img['permalink']) ?>"
       style="animation-delay: <?= min(($globalIndex % 9) * 0.06, 0.5) ?>s">
    <div class="sg-photo-inner">
      <img src="<?= htmlspecialchars($img['thumb']) ?>" alt="" loading="lazy">
    </div>
  </div>
<?php $globalIndex++; endforeach; ?>
</div>
<?php endif; ?>

<?php endif; ?>
        </main>

        <div class="sg-lightbox" id="sgLightbox">
            <div class="sg-lightbox-backdrop"></div>
            <div class="sg-lightbox-header">
                <span></span>
                <a class="sg-lightbox-title" id="sgLbTitle" href="#" target="_blank" title="">图片</a>
                <button class="sg-lightbox-close" id="sgLbClose">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
            </div>
            <div class="sg-lightbox-stage" id="sgLbStage">
                <button class="sg-lightbox-arrow prev" id="sgLbPrev">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
                </button>
                <div class="sg-lightbox-imgbox">
                    <img class="sg-lightbox-img" id="sgLbImg" src="" alt="">
                </div>
                <button class="sg-lightbox-arrow next" id="sgLbNext">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
                </button>
            </div>
            <div class="sg-lightbox-bar">
                <div class="sg-lightbox-counter" id="sgLbCounter">1 / 1</div>
                <div class="sg-lightbox-thumbs" id="sgLbThumbs"></div>
            </div>
        </div>
    </div>
</div>

<script>
const sgArticles = <?= json_encode($allArticles) ?>;
let sgFlatImages = [];
let sgMode = '<?= $gridColumns == 2 ? 'article' : 'single' ?>';

if (sgMode === 'single') {
    sgArticles.forEach(article => {
        article.images.forEach(img => {
            sgFlatImages.push({ url: img.url, thumb: img.thumb, title: article.title, permalink: article.permalink });
        });
    });
}

const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            revealObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.05, rootMargin: '0px 0px -30px 0px' });

document.querySelectorAll('.sg-reveal').forEach(el => revealObserver.observe(el));

let sgCurrentImages = [];
let sgCurrentIndex = 0;
const sgLightbox = document.getElementById('sgLightbox');
const sgLbImg = document.getElementById('sgLbImg');
const sgLbTitle = document.getElementById('sgLbTitle');
const sgLbCounter = document.getElementById('sgLbCounter');
const sgLbThumbs = document.getElementById('sgLbThumbs');
const sgLbPrev = document.getElementById('sgLbPrev');
const sgLbNext = document.getElementById('sgLbNext');
const sgLbClose = document.getElementById('sgLbClose');

function sgOpen(images, index, permalink, title) {
    sgCurrentImages = images;
    sgCurrentIndex = index;
    sgLbTitle.textContent = title || '图片';
    sgLbTitle.href = permalink || '#';
    sgLbTitle.title = title || '';
    sgUpdateLb();
    sgLightbox.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function sgUpdateLb() {
    if (!sgCurrentImages.length) return;
    const img = sgCurrentImages[sgCurrentIndex];
    sgLbImg.style.opacity = '0';
    sgLbImg.style.transform = 'scale(0.92)';
    setTimeout(() => {
        sgLbImg.src = img.url;
        sgLbImg.onload = () => {
            sgLbImg.style.opacity = '1';
            sgLbImg.style.transform = 'scale(1)';
        };
    }, 120);
    sgLbCounter.textContent = (sgCurrentIndex + 1) + ' / ' + sgCurrentImages.length;
    sgLbThumbs.innerHTML = sgCurrentImages.map((item, idx) =>
        '<div class="sg-lb-thumb ' + (idx === sgCurrentIndex ? 'active' : '') + '" data-index="' + idx + '">' +
        '<img src="' + item.thumb + '" alt="" loading="lazy">' +
        '</div>'
    ).join('');
    sgLbThumbs.querySelectorAll('.sg-lb-thumb').forEach(item => {
        item.addEventListener('click', () => { sgCurrentIndex = parseInt(item.dataset.index); sgUpdateLb(); });
    });
    sgLbPrev.style.opacity = sgCurrentIndex === 0 ? '0.2' : '1';
    sgLbNext.style.opacity = sgCurrentIndex === sgCurrentImages.length - 1 ? '0.2' : '1';
}

function sgPrev() { if (sgCurrentIndex > 0) { sgCurrentIndex--; sgUpdateLb(); } }
function sgNext() { if (sgCurrentIndex < sgCurrentImages.length - 1) { sgCurrentIndex++; sgUpdateLb(); } }
function sgClose() { sgLightbox.classList.remove('active'); document.body.style.overflow = ''; }

document.querySelectorAll('.sg-wf-item').forEach((card, idx) => {
    card.addEventListener('click', () => {
        const article = sgArticles[idx];
        if (article && article.images) {
            sgOpen(article.images, 0, article.permalink, article.title);
        }
    });
});

document.querySelectorAll('.sg-photo').forEach((item, idx) => {
    item.addEventListener('click', () => {
        if (sgFlatImages[idx]) {
            sgOpen(sgFlatImages, idx, sgFlatImages[idx].permalink, sgFlatImages[idx].title);
        }
    });
});

sgLbClose.addEventListener('click', sgClose);
sgLbPrev.addEventListener('click', sgPrev);
sgLbNext.addEventListener('click', sgNext);
document.querySelector('.sg-lightbox-backdrop').addEventListener('click', sgClose);

document.addEventListener('keydown', (e) => {
    if (sgLightbox.classList.contains('active')) {
        if (e.key === 'ArrowLeft') sgPrev();
        if (e.key === 'ArrowRight') sgNext();
        if (e.key === 'Escape') sgClose();
    }
});

let sgTouchX = 0;
const lbStage = document.getElementById('sgLbStage');
if (lbStage) {
    lbStage.addEventListener('touchstart', (e) => {
        sgTouchX = e.changedTouches[0].screenX;
    }, { passive: true });
    lbStage.addEventListener('touchend', (e) => {
        const diff = sgTouchX - e.changedTouches[0].screenX;
        if (Math.abs(diff) > 60) { diff > 0 ? sgNext() : sgPrev(); }
    }, { passive: true });
}
</script>

</body>
</html>
<?php

namespace TypechoPlugin\ShiGuang;

use Typecho\Plugin\PluginInterface;
use Typecho\Widget;
use Typecho\Db;
use Typecho\Db\Exception;
use Typecho\Router;
use Widget\Options;
use Utils\Helper;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Text;
use Typecho\Widget\Helper\Form\Element\Radio;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 *Typecho独立相册插件，双列瀑布流与三列网格一键切换
 *
 * @package 拾光·极简相册
 * @author Lin.
 * @link https://linyu.live
 * @version 2.2.2
 */
class Plugin implements PluginInterface
{
    public static function activate()
    {
        Helper::addRoute('shiguang', '/shiguang', 'ShiGuang_Action', 'render');
        self::deployAssets();
        return _t('相册插件已激活，访问 /shiguang 查看相册，或在后台新建独立页面选择「拾光·极简相册」模板');
    }

    public static function deactivate()
    {
        Helper::removeRoute('shiguang');
        return _t('相册插件已禁用');
    }

    public static function config(Form $form)
    {
        $title = new Text('title', null, '我的相册', _t('相册标题'), _t('显示在顶栏和首图左下角的大标题/独立路由专用'));
        $form->addInput($title);

        $description = new Text('description', null, 'Scenery along the way', _t('相册副标题'), _t('显示在首图左下角的小字/英文/独立路由专用'));
        $form->addInput($description);

        $category = new Text('category', null, '0', _t('默认分类ID'), _t('支持多个分类ID，用英文逗号分隔，如：2,3,5<br>填 0 或留空则显示所有分类的文章'));
        $form->addInput($category);

        $headerBg = new Text('headerBg', null, 'img/photo.webp', _t('首图背景'), _t('相对于插件目录的路径（如 img/photo.webp）或完整URL/独立路由专用'));
        $form->addInput($headerBg);

        $gridColumns = new Radio('gridColumns',
            ['3' => _t('三列网格（小图，密集瀑布流）'), '2' => _t('双列网格（大图，瀑布流卡片）')],
            '3',
            _t('网格布局')
        );
        $form->addInput($gridColumns);
    }

    public static function personalConfig(Form $form)
    {
    }

    public static function getAlbumData(): array
    {
        try {
            $options = Options::alloc()->plugin('ShiGuang');
            $categoryParam = $options->category;
            $categoryIds = self::parseCategoryIds($categoryParam);
            return self::getGroupedImages($categoryIds);
        } catch (\Throwable $e) {
            return [];
        }
    }

    private static function deployAssets(): void
    {
        $theme = Options::alloc()->theme;
        if (empty($theme)) {
            return;
        }

        $themeDir = __TYPECHO_ROOT_DIR__ . '/usr/themes/' . $theme . '/';
        if (!is_dir($themeDir)) {
            return;
        }

        // 1. 自动部署主题模板 page-photo.php
        $targetTemplate = $themeDir . 'page-photo.php';
        @file_put_contents($targetTemplate, self::getTemplateContent(), LOCK_EX);

        // 2. 确保 views 目录和 CSS 文件
        $cssDir = __DIR__ . '/views/';
        if (!is_dir($cssDir)) {
            @mkdir($cssDir, 0755, true);
        }
        $cssFile = $cssDir . 'shiguang.css';
        @file_put_contents($cssFile, self::getCSSContent(), LOCK_EX);

        // 3. 确保 views/shiguang.php 存在（供 /shiguang 路由使用）
        $viewFile = $cssDir . 'shiguang.php';
        @file_put_contents($viewFile, self::getViewContent(), LOCK_EX);
    }

    private static function getTemplateContent(): string
    {
        return <<<'TPL'
<?php
/**
 * 拾光·极简相册
 *
 * @package custom
 * @template Photo
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('include/header.php');

$opts = $this->options->plugin('ShiGuang');
$gridColumns = intval($opts->gridColumns) ?: 3;

$allArticles = [];
try {
    if (class_exists('TypechoPlugin\ShiGuang\Plugin')) {
        $allArticles = \TypechoPlugin\ShiGuang\Plugin::getAlbumData();
    }
} catch (\Throwable $e) { $allArticles = []; }

$pluginUrl = $this->options->pluginUrl . '/ShiGuang';
?>

<link rel="stylesheet" href="<?= $pluginUrl ?>/views/shiguang.css">

<div class="row justify-content-center <?= ($this->options->SidebarRorL == 'R-L') ? 'flex-row-reverse' : '' ?>">
    <?php Context::SidebarEcho($this) ?>
    <div class="my-4 col-lg-9">
        <div class="sg-wrap">
            <main>
<?php if (empty($allArticles)): ?>
                <div class="sg-empty">
                    <div class="icon">📷</div>
                    <div class="txt">暂无图片</div>
                </div>
<?php else: ?>

<?php if ($gridColumns == 2): ?>
<!-- 双列瀑布流（小红书风） -->
<div class="sg-waterfall" id="sgWaterfall">
<?php $articleIndex = 0; foreach ($allArticles as $article):
    $isSingle = $article['count'] <= 1;
    $firstImg = $article['images'][0];
    $delay = min($articleIndex * 0.08, 0.8);
?>
  <div class="sg-wf-item sg-reveal"
       data-index="<?= $articleIndex ?>"
       data-cid="<?= $article['cid'] ?>"
       style="animation-delay: <?= $delay ?>s">
    <div class="sg-wf-visual">
      <img src="<?= htmlspecialchars($firstImg['thumb']) ?>"
           alt="<?= htmlspecialchars($article['title']) ?>"
           loading="lazy">
      <?php if (!$isSingle): ?>
      <div class="sg-wf-count"><?= $article['count'] ?></div>
      <?php endif; ?>
    </div>
    <div class="sg-wf-body">
      <div class="sg-wf-title"><?= htmlspecialchars($article['title']) ?></div>
      <div class="sg-wf-date"><?= htmlspecialchars($article['date']) ?></div>
    </div>
  </div>
<?php $articleIndex++; endforeach; ?>
</div>

<?php else: ?>
<!-- 三列大图（边缘贴合） -->
<?php
$flatImages = [];
foreach ($allArticles as $article) {
    foreach ($article['images'] as $img) {
        $flatImages[] = [
            'url'       => $img['url'],
            'thumb'     => $img['thumb'],
            'title'     => $article['title'],
            'permalink' => $article['permalink']
        ];
    }
}
?>
<div class="sg-3col" id="sg3col">
<?php $globalIndex = 0; foreach ($flatImages as $img): ?>
  <div class="sg-photo sg-reveal"
       data-index="<?= $globalIndex ?>"
       data-url="<?= htmlspecialchars($img['url']) ?>"
       data-title="<?= htmlspecialchars($img['title']) ?>"
       data-thumb="<?= htmlspecialchars($img['thumb']) ?>"
       data-permalink="<?= htmlspecialchars($img['permalink']) ?>"
       style="animation-delay: <?= min(($globalIndex % 9) * 0.06, 0.5) ?>s">
    <div class="sg-photo-inner">
      <img src="<?= htmlspecialchars($img['thumb']) ?>" alt="" loading="lazy">
    </div>
  </div>
<?php $globalIndex++; endforeach; ?>
</div>
<?php endif; ?>

<?php endif; ?>
            </main>

            <!-- 现代灯箱 -->
            <div class="sg-lightbox" id="sgLightbox">
                <div class="sg-lightbox-backdrop"></div>
                <div class="sg-lightbox-header">
                    <span></span>
                    <a class="sg-lightbox-title" id="sgLbTitle" href="#" target="_blank" title="">图片</a>
                    <button class="sg-lightbox-close" id="sgLbClose">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                    </button>
                </div>
                <div class="sg-lightbox-stage" id="sgLbStage">
                    <button class="sg-lightbox-arrow prev" id="sgLbPrev">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
                    </button>
                    <div class="sg-lightbox-imgbox">
                        <img class="sg-lightbox-img" id="sgLbImg" src="" alt="">
                    </div>
                    <button class="sg-lightbox-arrow next" id="sgLbNext">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
                    </button>
                </div>
                <div class="sg-lightbox-bar">
                    <div class="sg-lightbox-counter" id="sgLbCounter">1 / 1</div>
                    <div class="sg-lightbox-thumbs" id="sgLbThumbs"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const sgArticles = <?= json_encode($allArticles) ?>;
let sgFlatImages = [];
let sgMode = '<?= $gridColumns == 2 ? 'article' : 'single' ?>';

if (sgMode === 'single') {
    sgArticles.forEach(article => {
        article.images.forEach(img => {
            sgFlatImages.push({ url: img.url, thumb: img.thumb, title: article.title, permalink: article.permalink });
        });
    });
}

const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            revealObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.05, rootMargin: '0px 0px -30px 0px' });

document.querySelectorAll('.sg-reveal').forEach(el => revealObserver.observe(el));

let sgCurrentImages = [];
let sgCurrentIndex = 0;
const sgLightbox = document.getElementById('sgLightbox');
const sgLbImg = document.getElementById('sgLbImg');
const sgLbTitle = document.getElementById('sgLbTitle');
const sgLbCounter = document.getElementById('sgLbCounter');
const sgLbThumbs = document.getElementById('sgLbThumbs');
const sgLbPrev = document.getElementById('sgLbPrev');
const sgLbNext = document.getElementById('sgLbNext');
const sgLbClose = document.getElementById('sgLbClose');

function sgOpen(images, index, permalink, title) {
    sgCurrentImages = images;
    sgCurrentIndex = index;
    sgLbTitle.textContent = title || '图片';
    sgLbTitle.href = permalink || '#';
    sgLbTitle.title = title || '';
    sgUpdateLb();
    sgLightbox.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function sgUpdateLb() {
    if (!sgCurrentImages.length) return;
    const img = sgCurrentImages[sgCurrentIndex];
    sgLbImg.style.opacity = '0';
    sgLbImg.style.transform = 'scale(0.92)';
    setTimeout(() => {
        sgLbImg.src = img.url;
        sgLbImg.onload = () => {
            sgLbImg.style.opacity = '1';
            sgLbImg.style.transform = 'scale(1)';
        };
    }, 120);
    sgLbCounter.textContent = (sgCurrentIndex + 1) + ' / ' + sgCurrentImages.length;
    sgLbThumbs.innerHTML = sgCurrentImages.map((item, idx) =>
        '<div class="sg-lb-thumb ' + (idx === sgCurrentIndex ? 'active' : '') + '" data-index="' + idx + '">' +
        '<img src="' + item.thumb + '" alt="" loading="lazy">' +
        '</div>'
    ).join('');
    sgLbThumbs.querySelectorAll('.sg-lb-thumb').forEach(item => {
        item.addEventListener('click', () => { sgCurrentIndex = parseInt(item.dataset.index); sgUpdateLb(); });
    });
    sgLbPrev.style.opacity = sgCurrentIndex === 0 ? '0.2' : '1';
    sgLbNext.style.opacity = sgCurrentIndex === sgCurrentImages.length - 1 ? '0.2' : '1';
}

function sgPrev() { if (sgCurrentIndex > 0) { sgCurrentIndex--; sgUpdateLb(); } }
function sgNext() { if (sgCurrentIndex < sgCurrentImages.length - 1) { sgCurrentIndex++; sgUpdateLb(); } }
function sgClose() { sgLightbox.classList.remove('active'); document.body.style.overflow = ''; }

document.querySelectorAll('.sg-wf-item').forEach((card, idx) => {
    card.addEventListener('click', () => {
        const article = sgArticles[idx];
        if (article && article.images) {
            sgOpen(article.images, 0, article.permalink, article.title);
        }
    });
});

document.querySelectorAll('.sg-photo').forEach((item, idx) => {
    item.addEventListener('click', () => {
        if (sgFlatImages[idx]) {
            sgOpen(sgFlatImages, idx, sgFlatImages[idx].permalink, sgFlatImages[idx].title);
        }
    });
});

sgLbClose.addEventListener('click', sgClose);
sgLbPrev.addEventListener('click', sgPrev);
sgLbNext.addEventListener('click', sgNext);
document.querySelector('.sg-lightbox-backdrop').addEventListener('click', sgClose);

document.addEventListener('keydown', (e) => {
    if (sgLightbox.classList.contains('active')) {
        if (e.key === 'ArrowLeft') sgPrev();
        if (e.key === 'ArrowRight') sgNext();
        if (e.key === 'Escape') sgClose();
    }
});

let sgTouchX = 0;
const lbStage = document.getElementById('sgLbStage');
if (lbStage) {
    lbStage.addEventListener('touchstart', (e) => {
        sgTouchX = e.changedTouches[0].screenX;
    }, { passive: true });
    lbStage.addEventListener('touchend', (e) => {
        const diff = sgTouchX - e.changedTouches[0].screenX;
        if (Math.abs(diff) > 60) { diff > 0 ? sgNext() : sgPrev(); }
    }, { passive: true });
}
</script>

<?php $this->need('include/footer.php'); ?>
TPL;
    }

    private static function getViewContent(): string
    {
        return <<<'VIEW'
<?php
/**
 * /shiguang 路由专用视图
 */

use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$opts = Options::alloc()->plugin('ShiGuang');
$gridColumns = intval($opts->gridColumns) ?: 3;

$allArticles = [];
try {
    if (class_exists('TypechoPlugin\ShiGuang\Plugin')) {
        $allArticles = \TypechoPlugin\ShiGuang\Plugin::getAlbumData();
    }
} catch (\Throwable $e) { $allArticles = []; }

$pluginUrl = Options::alloc()->pluginUrl . '/ShiGuang';
$albumTitle = $opts->title ?? '我的相册';
$albumDesc = $opts->description ?? '';
$headerBg = !empty($opts->headerBg)
    ? (strpos($opts->headerBg, 'http') === 0 ? $opts->headerBg : $pluginUrl . '/' . ltrim($opts->headerBg, '/'))
    : '';
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?= htmlspecialchars($albumTitle) ?></title>
    <link rel="stylesheet" href="<?= $pluginUrl ?>/views/shiguang.css">
    <style>
        .sg-hero {
            position: relative;
            height: 28vh;
            min-height: 160px;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            padding: 0 16px 20px;
            background: linear-gradient(to bottom, rgba(0,0,0,0) 0%, rgba(0,0,0,0.55) 100%), url('<?= htmlspecialchars($headerBg) ?>') center/cover no-repeat;
            color: #fff;
        }
        .sg-hero h1 { font-size: 1.6rem; font-weight: 700; margin: 0 0 6px; letter-spacing: 1px; }
        .sg-hero p { font-size: 0.8rem; opacity: 0.75; margin: 0; }
        @media (min-width: 768px) {
            .sg-hero { height: 24vh; min-height: 200px; padding: 0 24px 28px; }
            .sg-hero h1 { font-size: 2rem; }
            .sg-hero p { font-size: 0.9rem; }
        }
    </style>
</head>
<body>

<!-- 手机端顶栏 -->
<div class="sg-mobile-header">
    <a href="javascript:history.back()" class="sg-back">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
    </a>
    <h1><?= htmlspecialchars($albumTitle) ?></h1>
    <span style="width:24px;"></span>
</div>

<div class="sg-hero">
    <h1><?= htmlspecialchars($albumTitle) ?></h1>
    <p><?= htmlspecialchars($albumDesc) ?></p>
</div>

<div class="sg-page">
    <div class="sg-wrap">
        <main>
<?php if (empty($allArticles)): ?>
            <div class="sg-empty">
                <div class="icon">📷</div>
                <div class="txt">暂无图片</div>
            </div>
<?php else: ?>

<?php if ($gridColumns == 2): ?>
<div class="sg-waterfall" id="sgWaterfall">
<?php $articleIndex = 0; foreach ($allArticles as $article):
    $isSingle = $article['count'] <= 1;
    $firstImg = $article['images'][0];
    $delay = min($articleIndex * 0.08, 0.8);
?>
  <div class="sg-wf-item sg-reveal"
       data-index="<?= $articleIndex ?>"
       data-cid="<?= $article['cid'] ?>"
       style="animation-delay: <?= $delay ?>s">
    <div class="sg-wf-visual">
      <img src="<?= htmlspecialchars($firstImg['thumb']) ?>"
           alt="<?= htmlspecialchars($article['title']) ?>"
           loading="lazy">
      <?php if (!$isSingle): ?>
      <div class="sg-wf-count"><?= $article['count'] ?></div>
      <?php endif; ?>
    </div>
    <div class="sg-wf-body">
      <div class="sg-wf-title"><?= htmlspecialchars($article['title']) ?></div>
      <div class="sg-wf-date"><?= htmlspecialchars($article['date']) ?></div>
    </div>
  </div>
<?php $articleIndex++; endforeach; ?>
</div>

<?php else: ?>
<?php
$flatImages = [];
foreach ($allArticles as $article) {
    foreach ($article['images'] as $img) {
        $flatImages[] = [
            'url'       => $img['url'],
            'thumb'     => $img['thumb'],
            'title'     => $article['title'],
            'permalink' => $article['permalink']
        ];
    }
}
?>
<div class="sg-3col" id="sg3col">
<?php $globalIndex = 0; foreach ($flatImages as $img): ?>
  <div class="sg-photo sg-reveal"
       data-index="<?= $globalIndex ?>"
       data-url="<?= htmlspecialchars($img['url']) ?>"
       data-title="<?= htmlspecialchars($img['title']) ?>"
       data-thumb="<?= htmlspecialchars($img['thumb']) ?>"
       data-permalink="<?= htmlspecialchars($img['permalink']) ?>"
       style="animation-delay: <?= min(($globalIndex % 9) * 0.06, 0.5) ?>s">
    <div class="sg-photo-inner">
      <img src="<?= htmlspecialchars($img['thumb']) ?>" alt="" loading="lazy">
    </div>
  </div>
<?php $globalIndex++; endforeach; ?>
</div>
<?php endif; ?>

<?php endif; ?>
        </main>

        <div class="sg-lightbox" id="sgLightbox">
            <div class="sg-lightbox-backdrop"></div>
            <div class="sg-lightbox-header">
                <span></span>
                <a class="sg-lightbox-title" id="sgLbTitle" href="#" target="_blank" title="">图片</a>
                <button class="sg-lightbox-close" id="sgLbClose">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
            </div>
            <div class="sg-lightbox-stage" id="sgLbStage">
                <button class="sg-lightbox-arrow prev" id="sgLbPrev">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
                </button>
                <div class="sg-lightbox-imgbox">
                    <img class="sg-lightbox-img" id="sgLbImg" src="" alt="">
                </div>
                <button class="sg-lightbox-arrow next" id="sgLbNext">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
                </button>
            </div>
            <div class="sg-lightbox-bar">
                <div class="sg-lightbox-counter" id="sgLbCounter">1 / 1</div>
                <div class="sg-lightbox-thumbs" id="sgLbThumbs"></div>
            </div>
        </div>
    </div>
</div>

<script>
const sgArticles = <?= json_encode($allArticles) ?>;
let sgFlatImages = [];
let sgMode = '<?= $gridColumns == 2 ? 'article' : 'single' ?>';

if (sgMode === 'single') {
    sgArticles.forEach(article => {
        article.images.forEach(img => {
            sgFlatImages.push({ url: img.url, thumb: img.thumb, title: article.title, permalink: article.permalink });
        });
    });
}

const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            revealObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.05, rootMargin: '0px 0px -30px 0px' });

document.querySelectorAll('.sg-reveal').forEach(el => revealObserver.observe(el));

let sgCurrentImages = [];
let sgCurrentIndex = 0;
const sgLightbox = document.getElementById('sgLightbox');
const sgLbImg = document.getElementById('sgLbImg');
const sgLbTitle = document.getElementById('sgLbTitle');
const sgLbCounter = document.getElementById('sgLbCounter');
const sgLbThumbs = document.getElementById('sgLbThumbs');
const sgLbPrev = document.getElementById('sgLbPrev');
const sgLbNext = document.getElementById('sgLbNext');
const sgLbClose = document.getElementById('sgLbClose');

function sgOpen(images, index, permalink, title) {
    sgCurrentImages = images;
    sgCurrentIndex = index;
    sgLbTitle.textContent = title || '图片';
    sgLbTitle.href = permalink || '#';
    sgLbTitle.title = title || '';
    sgUpdateLb();
    sgLightbox.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function sgUpdateLb() {
    if (!sgCurrentImages.length) return;
    const img = sgCurrentImages[sgCurrentIndex];
    sgLbImg.style.opacity = '0';
    sgLbImg.style.transform = 'scale(0.92)';
    setTimeout(() => {
        sgLbImg.src = img.url;
        sgLbImg.onload = () => {
            sgLbImg.style.opacity = '1';
            sgLbImg.style.transform = 'scale(1)';
        };
    }, 120);
    sgLbCounter.textContent = (sgCurrentIndex + 1) + ' / ' + sgCurrentImages.length;
    sgLbThumbs.innerHTML = sgCurrentImages.map((item, idx) =>
        '<div class="sg-lb-thumb ' + (idx === sgCurrentIndex ? 'active' : '') + '" data-index="' + idx + '">' +
        '<img src="' + item.thumb + '" alt="" loading="lazy">' +
        '</div>'
    ).join('');
    sgLbThumbs.querySelectorAll('.sg-lb-thumb').forEach(item => {
        item.addEventListener('click', () => { sgCurrentIndex = parseInt(item.dataset.index); sgUpdateLb(); });
    });
    sgLbPrev.style.opacity = sgCurrentIndex === 0 ? '0.2' : '1';
    sgLbNext.style.opacity = sgCurrentIndex === sgCurrentImages.length - 1 ? '0.2' : '1';
}

function sgPrev() { if (sgCurrentIndex > 0) { sgCurrentIndex--; sgUpdateLb(); } }
function sgNext() { if (sgCurrentIndex < sgCurrentImages.length - 1) { sgCurrentIndex++; sgUpdateLb(); } }
function sgClose() { sgLightbox.classList.remove('active'); document.body.style.overflow = ''; }

document.querySelectorAll('.sg-wf-item').forEach((card, idx) => {
    card.addEventListener('click', () => {
        const article = sgArticles[idx];
        if (article && article.images) {
            sgOpen(article.images, 0, article.permalink, article.title);
        }
    });
});

document.querySelectorAll('.sg-photo').forEach((item, idx) => {
    item.addEventListener('click', () => {
        if (sgFlatImages[idx]) {
            sgOpen(sgFlatImages, idx, sgFlatImages[idx].permalink, sgFlatImages[idx].title);
        }
    });
});

sgLbClose.addEventListener('click', sgClose);
sgLbPrev.addEventListener('click', sgPrev);
sgLbNext.addEventListener('click', sgNext);
document.querySelector('.sg-lightbox-backdrop').addEventListener('click', sgClose);

document.addEventListener('keydown', (e) => {
    if (sgLightbox.classList.contains('active')) {
        if (e.key === 'ArrowLeft') sgPrev();
        if (e.key === 'ArrowRight') sgNext();
        if (e.key === 'Escape') sgClose();
    }
});

let sgTouchX = 0;
const lbStage = document.getElementById('sgLbStage');
if (lbStage) {
    lbStage.addEventListener('touchstart', (e) => {
        sgTouchX = e.changedTouches[0].screenX;
    }, { passive: true });
    lbStage.addEventListener('touchend', (e) => {
        const diff = sgTouchX - e.changedTouches[0].screenX;
        if (Math.abs(diff) > 60) { diff > 0 ? sgNext() : sgPrev(); }
    }, { passive: true });
}
</script>

</body>
</html>
VIEW;
    }

    private static function getCSSContent(): string
    {
        return <<<'CSS'
/* ===== 拾光相册 2.2.2 - 自然瀑布流 ===== */
.sg-wrap {
  --bg: #f8fafc;
  --card: #ffffff;
  --text: #1f2937;
  --sub: #6b7280;
  --light: #9ca3af;
  --border: rgba(0,0,0,.04);
  --accent: #3b82f6;
  --accent-rgb: 59,130,246;
  --shadow: 0 2px 8px rgba(0,0,0,.06);
  --shadow-lg: 0 8px 24px rgba(0,0,0,.1);
  --radius: 12px;
}

[data-theme="dark"] .sg-wrap,
html[data-theme="dark"] .sg-wrap,
.dark .sg-wrap,
body.dark .sg-wrap {
  --bg: #1f2937;
  --card: #111827;
  --text: #f1f5f9;
  --sub: #94a3b8;
  --light: #64748b;
  --border: rgba(255,255,255,.04);
  --accent: #60a5fa;
  --accent-rgb: 96,165,250;
  --shadow: 0 2px 8px rgba(0,0,0,.2);
  --shadow-lg: 0 8px 24px rgba(0,0,0,.35);
}

.sg-wrap {
  background: var(--bg);
  min-height: 60vh;
  color: var(--text);
}

/* ===== 手机端路由顶栏 ===== */
.sg-mobile-header {
  display: none;
}

@media (max-width: 768px) {
  .sg-mobile-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 16px;
    background: #fff;
    border-bottom: 1px solid rgba(0,0,0,.06);
    position: sticky;
    top: 0;
    z-index: 100;
  }
  .sg-mobile-header h1 {
    font-size: 1rem;
    font-weight: 600;
    margin: 0;
    color: #1f2937;
  }
  .sg-mobile-header .sg-back {
    color: #1f2937;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
  }
}

[data-theme="dark"] .sg-mobile-header,
html[data-theme="dark"] .sg-mobile-header,
.dark .sg-mobile-header,
body.dark .sg-mobile-header {
  background: #111827;
  border-bottom-color: rgba(255,255,255,.06);
}
[data-theme="dark"] .sg-mobile-header h1,
html[data-theme="dark"] .sg-mobile-header h1,
.dark .sg-mobile-header h1,
body.dark .sg-mobile-header h1 {
  color: #f1f5f9;
}
[data-theme="dark"] .sg-mobile-header .sg-back,
html[data-theme="dark"] .sg-mobile-header .sg-back,
.dark .sg-mobile-header .sg-back,
body.dark .sg-mobile-header .sg-back {
  color: #f1f5f9;
}

/* ===== 双列瀑布流（小红书风 · 自然高度） ===== */
.sg-waterfall {
  column-count: 2;
  column-gap: 6px;
  padding: 5px;
}

.sg-wf-item {
  break-inside: avoid;
  margin-bottom: 6px;
  border-radius: var(--radius);
  overflow: hidden;
  cursor: pointer;
  transition: transform 0.3s ease;
  opacity: 0;
  transform: translateY(40px);
}

.sg-wf-item.visible {
  opacity: 1;
  transform: translateY(0);
}

.sg-wf-item:hover {
  transform: translateY(-2px);
}

.sg-wf-visual {
  position: relative;
  width: 100%;
  overflow: hidden;
  border-radius: var(--radius);
  background: linear-gradient(135deg, #f1f5f9, #e2e8f0);
  min-height: 160px;
}

[data-theme="dark"] .sg-wf-visual {
  background: linear-gradient(135deg, #374151, #1f2937);
}

.sg-wf-visual img {
  width: 100%;
  height: auto;
  display: block;
  object-fit: cover;
  border-radius: var(--radius);
  transition: transform 0.5s ease, opacity 0.4s ease;
}

.sg-wf-item:hover .sg-wf-visual img {
  transform: scale(1.03);
}

.sg-wf-count {
  position: absolute;
  top: 8px;
  right: 8px;
  background: rgba(0,0,0,0.35);
  color: #fff;
  padding: 3px 8px;
  border-radius: 10px;
  font-size: 0.7rem;
  font-weight: 500;
  z-index: 2;
  backdrop-filter: blur(6px);
  line-height: 1;
}

.sg-wf-body {
  padding: 8px 4px 4px;
}

.sg-wf-title {
  font-size: 0.8rem;
  font-weight: 500;
  color: var(--text);
  line-height: 1.4;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}

.sg-wf-date {
  font-size: 0.7rem;
  color: var(--light);
  margin-top: 3px;
  opacity: 0.65;
}

/* ===== 三列大图（边缘贴合、无白边） ===== */
.sg-3col {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 5px;
  padding: 5px;
}

.sg-photo {
  position: relative;
  border-radius: var(--radius);
  overflow: hidden;
  cursor: zoom-in;
  transition: all 0.35s cubic-bezier(.4,0,.2,1);
  box-shadow: var(--shadow);
  background: var(--card);
  opacity: 0;
  transform: translateY(40px);
}

.sg-photo.visible {
  opacity: 1;
  transform: translateY(0);
}

.sg-photo-inner {
  position: relative;
  width: 100%;
  aspect-ratio: 1/1;
  overflow: hidden;
}

.sg-photo-inner img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  transition: transform 0.5s cubic-bezier(.4,0,.2,1);
}

.sg-photo:hover {
  transform: translateY(-2px) scale(1.02);
  box-shadow: var(--shadow-lg);
  z-index: 5;
}

.sg-photo:hover .sg-photo-inner img {
  transform: scale(1.08);
}

/* ===== 滚动入场动画 ===== */
.sg-reveal {
  transition: opacity 0.8s cubic-bezier(.4,0,.2,1), transform 0.8s cubic-bezier(.4,0,.2,1);
}

/* ===== 现代灯箱（沉浸优化） ===== */
.sg-lightbox {
  position: fixed;
  inset: 0;
  z-index: 9999;
  display: none;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.sg-lightbox.active {
  display: flex;
}

.sg-lightbox-backdrop {
  position: absolute;
  inset: 0;
  background: rgba(0, 0, 0, 0.92);
  backdrop-filter: blur(30px) saturate(160%);
  -webkit-backdrop-filter: blur(30px) saturate(160%);
  opacity: 0;
  transition: opacity 0.4s ease;
}

.sg-lightbox.active .sg-lightbox-backdrop {
  opacity: 1;
}

.sg-lightbox-header {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 56px;
  z-index: 10;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
  opacity: 0;
  transform: translateY(-10px);
  transition: all 0.4s ease 0.1s;
}

.sg-lightbox.active .sg-lightbox-header {
  opacity: 1;
  transform: translateY(0);
}

.sg-lightbox-title {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  font-size: 0.82rem;
  color: rgba(255,255,255,0.9);
  text-decoration: none;
  padding: 6px 16px;
  border-radius: 20px;
  background: rgba(255,255,255,0.08);
  transition: background 0.3s;
  max-width: 70%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.sg-lightbox-title:hover {
  background: rgba(255,255,255,0.18);
}

.sg-lightbox-close {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: rgba(255,255,255,0.08);
  border: none;
  color: #fff;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s;
  margin-left: auto;
  z-index: 11;
}

.sg-lightbox-close:hover {
  background: rgba(255,255,255,0.2);
  transform: rotate(90deg);
}

.sg-lightbox-stage {
  position: relative;
  width: 100%;
  height: calc(100% - 150px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 5;
  opacity: 0;
  transform: scale(0.92);
  transition: all 0.5s cubic-bezier(.4,0,.2,1) 0.08s;
}

.sg-lightbox.active .sg-lightbox-stage {
  opacity: 1;
  transform: scale(1);
}

.sg-lightbox-imgbox {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 10px 52px;
}

.sg-lightbox-img {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
  border-radius: 8px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.5);
  transition: opacity 0.35s ease, transform 0.35s cubic-bezier(.4,0,.2,1);
}

.sg-lightbox-arrow {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 44px;
  height: 44px;
  border-radius: 50%;
  background: rgba(255,255,255,0.06);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  border: none;
  backdrop-filter: blur(8px);
  transition: all 0.3s;
  z-index: 10;
}

.sg-lightbox-arrow:hover {
  background: rgba(255,255,255,0.2);
  transform: translateY(-50%) scale(1.1);
}

.sg-lightbox-arrow.prev { left: 10px; }
.sg-lightbox-arrow.next { right: 10px; }

.sg-lightbox-bar {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 10;
  padding: 12px 16px 24px;
  background: rgba(0,0,0,0.15);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  opacity: 0;
  transform: translateY(10px);
  transition: all 0.4s ease 0.15s;
}

.sg-lightbox.active .sg-lightbox-bar {
  opacity: 1;
  transform: translateY(0);
}

.sg-lightbox-counter {
  text-align: center;
  color: rgba(255,255,255,0.5);
  font-size: 0.78rem;
  margin-bottom: 10px;
  letter-spacing: 1.5px;
}

.sg-lightbox-thumbs {
  display: flex;
  gap: 8px;
  justify-content: center;
  overflow-x: auto;
  padding: 4px;
  scrollbar-width: none;
}

.sg-lightbox-thumbs::-webkit-scrollbar { display: none; }

.sg-lb-thumb {
  width: 52px;
  height: 40px;
  border-radius: 6px;
  overflow: hidden;
  cursor: pointer;
  border: 2px solid transparent;
  transition: all 0.3s;
  flex-shrink: 0;
  opacity: 0.5;
  transform: scale(1);
}

.sg-lb-thumb img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.sg-lb-thumb.active {
  border-color: rgb(var(--accent-rgb));
  opacity: 1;
  transform: scale(1.12);
  box-shadow: 0 4px 12px rgba(var(--accent-rgb), 0.3);
}

.sg-lb-thumb:hover {
  opacity: 0.85;
  transform: scale(1.05);
}

/* ===== 空状态 ===== */
.sg-empty {
  text-align: center;
  padding: 100px 20px;
  color: var(--light);
}

.sg-empty .icon {
  font-size: 3rem;
  margin-bottom: 16px;
  opacity: 0.3;
}

.sg-empty .txt {
  font-size: 0.9rem;
  color: var(--sub);
}

/* ===== PC 适配（尺寸缩小 + 布局由主题接管） ===== */
@media (min-width: 1024px) {
  .sg-wrap {
    max-width: 540px;
    margin: 0 auto;
  }
  
  .sg-waterfall {
    column-gap: 10px;
    padding: 10px 0;
  }
  .sg-wf-item {
    margin-bottom: 10px;
  }
  .sg-wf-visual {
    min-height: 140px;
  }
  .sg-wf-body {
    padding: 10px 4px 6px;
  }
  .sg-wf-title {
    font-size: 0.85rem;
  }
  
  .sg-3col {
    gap: 10px;
    padding: 10px 0;
  }
  
  .sg-lightbox-arrow {
    width: 48px;
    height: 48px;
  }
  .sg-lightbox-arrow.prev { left: 20px; }
  .sg-lightbox-arrow.next { right: 20px; }
  .sg-lightbox-imgbox { padding: 16px 80px; }
  .sg-lightbox-header { padding: 0 20px; height: 60px; }
  .sg-lightbox-bar { padding: 14px 20px 28px; }
  .sg-lb-thumb {
    width: 64px;
    height: 48px;
  }
}

@media (min-width: 1200px) {
  .sg-wrap {
    max-width: 580px;
  }
  .sg-waterfall {
    column-gap: 12px;
  }
  .sg-3col {
    gap: 12px;
  }
}
CSS;
    }

    private static function parseCategoryIds($categoryParam): array
    {
        if (empty($categoryParam) || $categoryParam === '0' || $categoryParam === 0) {
            return [];
        }
        if (is_array($categoryParam)) {
            $result = array_filter(array_map('intval', $categoryParam));
            return array_values(array_unique($result));
        }
        $ids = explode(',', $categoryParam);
        $result = [];
        foreach ($ids as $id) {
            $id = intval(trim($id));
            if ($id > 0) {
                $result[] = $id;
            }
        }
        return empty($result) ? [] : array_values(array_unique($result));
    }

    private static function getGroupedImages(array $categoryIds): array
    {
        $db = Db::get();
        $articles = [];

        try {
            $select = $db->select('table.contents.cid', 'table.contents.text', 'table.contents.created', 'table.contents.title', 'table.contents.slug')
                ->from('table.contents')
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.status = ?', 'publish');

            if (!empty($categoryIds)) {
                $select = $select->join('table.relationships', 'table.contents.cid = table.relationships.cid', Db::INNER_JOIN)
                                 ->where('table.relationships.mid IN ?', $categoryIds);
            }

            $select = $select->order('table.contents.created', Db::SORT_DESC);
            $posts = $db->fetchAll($select);

        } catch (Exception $e) {
            return [];
        }

        foreach ($posts as $post) {
            $images = self::extractImagesFromMarkdown($post['text']);
            if (empty($images)) {
                continue;
            }

            $safeImages = [];
            foreach ($images as $img) {
                $safeUrl = self::safeImageUrl($img['url']);
                if ($safeUrl) {
                    $safeImages[] = [
                        'url'   => $safeUrl,
                        'thumb' => $safeUrl,
                        'alt'   => $img['title'] ?: '图片'
                    ];
                }
            }

            if (empty($safeImages)) {
                continue;
            }

            $permalink = Router::url('post', [
                'cid'  => $post['cid'],
                'slug' => $post['slug'] ?: $post['cid']
            ], Options::alloc()->index);

            $articles[] = [
                'cid'       => $post['cid'],
                'title'     => self::truncateTitle($post['title'] ?? ''),
                'date'      => date('Y/n/j', $post['created']),
                'images'    => $safeImages,
                'count'     => count($safeImages),
                'permalink' => $permalink
            ];
        }

        return $articles;
    }

    private static function extractImagesFromMarkdown(string $text): array
    {
        $images = [];
        $definitions = [];

        preg_match_all('/^\s*\[([^\]]+)\]:\s*(\S+)(?:\s+(?:"|\')([^"\']+)(?:"|\'))?\s*$/m', $text, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $definitions[trim($match[1])] = trim($match[2]);
        }

        preg_match_all('/!\[([^\]]*)\]\[([^\]]+)\]/', $text, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $alt = trim($match[1]);
            $id = trim($match[2]);
            if (isset($definitions[$id])) {
                $images[] = ['title' => $alt ?: '无标题', 'url' => $definitions[$id]];
            }
        }

        preg_match_all('/!\[([^\]]*)\]\(([^)]+)\)/', $text, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $images[] = ['title' => trim($match[1]) ?: '无标题', 'url' => trim($match[2])];
        }

        return $images;
    }

    private static function safeImageUrl(string $url): string
    {
        $url = trim($url);
        if (preg_match('/^(https?:|data:image|\/)/i', $url)) {
            return $url;
        }
        if (strpos($url, '//') === 0) {
            return 'https:' . $url;
        }
        return '';
    }

    private static function truncateTitle(string $title): string
    {
        $title = trim($title);
        if (empty($title)) {
            return '无标题';
        }
        if (mb_strlen($title, 'UTF-8') > 7) {
            return mb_substr($title, 0, 7, 'UTF-8') . '...';
        }
        return $title;
    }
}
